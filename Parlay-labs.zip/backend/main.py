"""
Main entry point for the Parlay Labs backend.

This module sets up a FastAPI application with a handful of placeholder
endpoints. It is intended as a starting point for a sports analytics
platform that will serve probabilistic predictions and expected‑value
computations for parlays and individual bets.
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from .models.montecarlo import simulate_game
from .models.markov import simulate_markov_game
from .models.ev_calculator import calculate_ev


app = FastAPI(title="Parlay Labs API", version="0.1.0")


class SimulationRequest(BaseModel):
    """Pydantic model describing the payload expected for simulation requests."""

    team_a: str
    team_b: str
    num_simulations: int = 10000


class SimulationResponse(BaseModel):
    """Response model for a simulation request."""

    win_rate_a: float
    win_rate_b: float
    average_margin: float


class EVRequest(BaseModel):
    """Pydantic model describing the payload expected for EV calculations."""

    probability: float
    odds: float
    stake: float = 1.0


class EVResponse(BaseModel):
    """Response model for expected value calculations."""

    expected_value: float


@app.get("/")
async def root() -> dict[str, str]:
    """Root endpoint providing a simple status message."""
    return {"message": "Welcome to Parlay Labs API"}


@app.post("/simulate", response_model=SimulationResponse)
async def run_simulation(request: SimulationRequest) -> SimulationResponse:
    """Run a Monte Carlo simulation for a given matchup.

    Args:
        request: The simulation input containing team names and number of runs.

    Returns:
        An object with win rates and average margin of victory.
    """
    if request.num_simulations <= 0:
        raise HTTPException(status_code=400, detail="num_simulations must be positive")

    result = simulate_game(request.team_a, request.team_b, request.num_simulations)
    return SimulationResponse(**result)


@app.post("/markov", response_model=SimulationResponse)
async def run_markov_simulation(request: SimulationRequest) -> SimulationResponse:
    """Run a Markov chain based simulation for a given matchup.

    Args:
        request: The simulation input containing team names and number of runs.

    Returns:
        An object with win rates and average margin of victory.
    """
    result = simulate_markov_game(request.team_a, request.team_b, request.num_simulations)
    return SimulationResponse(**result)


@app.post("/ev", response_model=EVResponse)
async def compute_expected_value(request: EVRequest) -> EVResponse:
    """Calculate the expected value for a bet given probability, odds and stake.

    Args:
        request: The EV input with probability, odds and stake.

    Returns:
        An object containing the computed expected value.
    """
    if not (0 <= request.probability <= 1):
        raise HTTPException(status_code=400, detail="Probability must be between 0 and 1")
    if request.odds <= 0:
        raise HTTPException(status_code=400, detail="Odds must be positive")
    result = calculate_ev(request.probability, request.odds, request.stake)
    return EVResponse(expected_value=result)