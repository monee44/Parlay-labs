"""
Data ingestion and cleaning package.

This package contains modules for ingesting and cleaning sports and odds
data. These modules are placeholders and should be replaced with
implementations that interface with real‑world APIs and data sources.
"""