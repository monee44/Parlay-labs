"""
Data ingestion utilities for Parlay Labs.

This module defines functions for fetching and normalising raw data from
external sources such as sportsbook APIs and sports statistics providers.
Currently, it contains stub functions that return hard‑coded data. In
production, these should perform network requests, handle API keys and
rate limits, and normalise heterogeneous data into a consistent schema.
"""

from typing import Dict, Any


def fetch_live_odds(event_id: str) -> Dict[str, Any]:
    """Fetch live odds for a given event.

    Args:
        event_id: Identifier for the sporting event.

    Returns:
        A dictionary containing odds information.

    Note:
        This stub returns a static odds object. Replace with real API calls.
    """
    return {
        "event_id": event_id,
        "odds": {
            "moneyline": {
                "team_a": 1.90,
                "team_b": 1.90,
            },
            "spread": {
                "line": -3.5,
                "team_a": 1.95,
                "team_b": 1.85,
            },
            "total": {
                "points": 47.5,
                "over": 1.90,
                "under": 1.90,
            },
        },
    }


def fetch_team_stats(team_name: str) -> Dict[str, Any]:
    """Fetch historical statistics for a team.

    Args:
        team_name: Name of the team.

    Returns:
        A dictionary containing statistics for the team.

    Note:
        This stub returns made‑up statistics. Replace with real data ingestion.
    """
    return {
        "team": team_name,
        "points_per_game": 24.7,
        "yards_per_game": 350.1,
        "turnovers_per_game": 1.2,
    }