"""
Expected value computation utilities.

This module contains functions to calculate the expected monetary value
of a bet given the win probability, decimal odds and stake. The EV is
calculated as:

    EV = (probability * (payout - stake)) - ((1 - probability) * stake)

Decimal odds are assumed: payout = odds × stake.
"""

def calculate_ev(probability: float, odds: float, stake: float = 1.0) -> float:
    """Calculate expected value (EV) of a bet.

    Args:
        probability: Probability of winning the bet (0 ≤ probability ≤ 1).
        odds: Decimal odds offered on the bet (> 0).
        stake: Amount staked on the bet.

    Returns:
        The expected value of the bet.

    Example:
        >>> calculate_ev(0.55, 1.91, 100)
        4.55

    """
    payout = odds * stake
    win_component = probability * (payout - stake)
    loss_component = (1 - probability) * stake
    expected_value = win_component - loss_component
    return expected_value