"""
Simple Monte Carlo simulation functions.

This module provides a stubbed implementation of a Monte Carlo simulation
for sports matchups. It randomly assigns outcomes based on uniform
probability. In a real system, this would be replaced with a sophisticated
model utilising historical data, player statistics and other domain
knowledge.
"""

import random
from typing import Dict


def simulate_game(team_a: str, team_b: str, num_simulations: int = 10000) -> Dict[str, float]:
    """Simulate a matchup between two teams using a rudimentary Monte Carlo method.

    Args:
        team_a: Name of the first team.
        team_b: Name of the second team.
        num_simulations: Number of simulation runs to perform.

    Returns:
        A dictionary containing win rates and average margin of victory.

    Note:
        This implementation assigns equal probability to both teams and
        generates a margin from a simple distribution. Replace this with
        actual model logic in production.
    """
    wins_a = 0
    wins_b = 0
    margin_total = 0.0
    for _ in range(num_simulations):
        # assign equal chance to each team
        winner = random.choice(["a", "b"])
        margin = random.gauss(mu=0, sigma=7)  # Gaussian margin with std deviation of 7 points
        if winner == "a":
            wins_a += 1
            margin_total += abs(margin)
        else:
            wins_b += 1
            margin_total -= abs(margin)
    win_rate_a = wins_a / num_simulations
    win_rate_b = wins_b / num_simulations
    average_margin = margin_total / num_simulations
    return {
        "win_rate_a": win_rate_a,
        "win_rate_b": win_rate_b,
        "average_margin": average_margin,
    }