"""Model package for Parlay Labs.

This package exposes simple functions for Monte Carlo and Markov chain simulations
as well as expected value calculations. The implementations are placeholders
intended to illustrate the project structure and should be replaced with
production‑grade models.
"""

from .montecarlo import simulate_game  # noqa: F401
from .markov import simulate_markov_game  # noqa: F401
from .ev_calculator import calculate_ev  # noqa: F401