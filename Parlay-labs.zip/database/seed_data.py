"""
Seed script for Parlay Labs database.

This script uses the built‑in sqlite3 module to initialise a small
dataset in an SQLite database. For production deployments, you may want to
replace this script with migration tools such as Alembic and use a proper
relational database such as PostgreSQL.
"""

import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS teams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    league TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    home_team_id INTEGER NOT NULL REFERENCES teams(id),
    away_team_id INTEGER NOT NULL REFERENCES teams(id),
    event_date TEXT NOT NULL,
    league TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS odds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER NOT NULL REFERENCES events(id),
    market_type TEXT NOT NULL,
    selection TEXT NOT NULL,
    price REAL NOT NULL,
    line REAL,
    created_at TEXT NOT NULL
);
"""

def initialise(db_path: str = "parlay.db") -> None:
    """Create tables and insert some sample data into the database."""
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.executescript(SCHEMA)
    # Insert sample teams
    teams = [
        ("Detroit Lions", "NFL"),
        ("Green Bay Packers", "NFL"),
        ("Los Angeles Lakers", "NBA"),
        ("Boston Celtics", "NBA"),
    ]
    for name, league in teams:
        cur.execute("INSERT OR IGNORE INTO teams (name, league) VALUES (?, ?)", (name, league))
    conn.commit()
    conn.close()


if __name__ == "__main__":
    initialise()