-- SQL schema for Parlay Labs

-- Table to store teams
CREATE TABLE IF NOT EXISTS teams (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    league TEXT NOT NULL
);

-- Table to store matches/events
CREATE TABLE IF NOT EXISTS events (
    id SERIAL PRIMARY KEY,
    home_team_id INTEGER NOT NULL REFERENCES teams(id),
    away_team_id INTEGER NOT NULL REFERENCES teams(id),
    event_date DATE NOT NULL,
    league TEXT NOT NULL
);

-- Table to store odds for events
CREATE TABLE IF NOT EXISTS odds (
    id SERIAL PRIMARY KEY,
    event_id INTEGER NOT NULL REFERENCES events(id),
    market_type TEXT NOT NULL, -- e.g. moneyline, spread, total
    selection TEXT NOT NULL,   -- e.g. home, away, over, under
    price DECIMAL(10, 4) NOT NULL, -- decimal odds
    line DECIMAL(10, 2),
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);