# 🧠 Parlay Labs — EV + Arbitrage Architect  

## AI‑Driven Sports Prediction & Parlay Analytics Platform

**Parlay Labs** is an open‑source, full‑stack sports analytics platform that combines advanced statistics, probability modelling and machine‑learning simulations to generate accurate, data‑driven betting insights and parlay recommendations.

### ⚙️ Overview

Parlay Labs unites expert‑level disciplines — **data science, quantitative finance and full‑stack engineering** — into one cohesive framework. It integrates real‑time odds, player and team statistics, and AI‑powered simulation engines to identify **positive expected‑value (+EV)** opportunities across sportsbooks.

### 🧩 Core Features

* **Live Data Ingestion** – Automated pipelines pull real‑time odds, injury reports and player stats from ESPN, DraftKings and BetMGM APIs.
* **Monte Carlo Simulator** – Runs tens of thousands of iterations per matchup to produce probability distributions for spreads, totals and moneylines.
* **Markov Engine** – Possession‑ and drive‑state modelling for NFL and NBA game flows.
* **EV & Arbitrage Calculator** – Computes implied odds, expected value and cross‑book discrepancies.
* **Parlay Builder UI** – An interactive React dashboard for custom multi‑leg parlay creation with live probability feedback.
* **Historical Backtesting** – Tracks accuracy with Brier Score, MAE and calibration charts.
* **Audit Log** – Transparent record of model performance and daily edge detection.

### 🧠 Architecture

| Layer       | Stack                                   |
|------------ |-----------------------------------------|
| Frontend    | React + TypeScript + Vite + Tailwind CSS |
| Backend API | FastAPI (Python) / Express (Node.js)     |
| Machine Learning | Python (pandas, NumPy, scikit‑learn, PyMC3, XGBoost) |
| Database    | PostgreSQL (primary) + Redis (cache)    |
| Deployment  | Vercel (frontend) + AWS Lambda / Docker (backend) |
| Version Control / CI‑CD | GitHub Actions + Pre‑commit Linting + Testing Suite |

### 🧮 Example Workflow

1. **Fetch Data** → ESPN/DraftKings API → normalize → store in PostgreSQL.
2. **Run Simulations** → Monte Carlo + Markov engines generate win % and totals distributions.
3. **Compute EV** → compare model probabilities vs. implied odds.
4. **Surface Edges** → display top +EV and arbitrage opportunities in the dashboard.
5. **Build Parlay** → user selects legs → system calculates combined probability & expected payout.

### 📁 Repository Structure

```
Parlay-labs/
├── backend/
│   ├── main.py                # FastAPI backend entry point
│   ├── models/
│   │   ├── __init__.py
│   │   ├── montecarlo.py     # Monte Carlo simulation logic
│   │   ├── markov.py         # Markov chain simulation logic
│   │   └── ev_calculator.py  # Expected value and bankroll utilities
│   └── data/
│       ├── __init__.py
│       ├── ingest.py         # Data ingestion scripts
│       └── clean.py          # Data cleaning and transformation
├── frontend/
│   ├── package.json          # Frontend dependencies and scripts
│   ├── src/
│   │   ├── components/
│   │   │   ├── ParlayBuilder.tsx
│   │   │   └── MCMCCrossCheckPanel.tsx
│   │   └── ParlayLabAnalyticsDashboard.tsx
│   └── tsconfig.json         # TypeScript configuration
├── database/
│   ├── schema.sql            # SQL schema definitions
│   └── seed_data.py          # Seed scripts for initial data
└── README.md                 # Project overview and documentation
```

### 🚀 Getting Started

1. **Clone the repo**
   ```bash
   git clone https://github.com/monee44/Parlay-labs.git
   cd Parlay-labs
   ```

2. **Backend setup**
   ```bash
   cd backend
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   uvicorn main:app --reload
   ```

3. **Frontend setup**
   ```bash
   cd ../frontend
   npm install
   npm run dev
   ```

Then visit `http://localhost:5173` to open the Parlay Labs dashboard.

### 🤝 Contributing

Pull requests and feature suggestions are welcome! See `CONTRIBUTING.md` for setup guidelines and branch workflow.

### 🧭 Vision

Parlay Labs aims to become the **gold standard for transparent, data‑driven sports prediction**, empowering users with responsible, mathematically sound betting tools that continuously self‑calibrate and improve.