import React from 'react';
import ParlayBuilder from './components/ParlayBuilder';
import MCMCCrossCheckPanel from './components/MCMCCrossCheckPanel';

/**
 * ParlayLabAnalyticsDashboard
 *
 * Main dashboard component for the Parlay Labs frontend. This aggregates
 * various panels and controls into a single page. Use a CSS framework like
 * Tailwind to organise layout and styling.
 */
export default function ParlayLabAnalyticsDashboard(): JSX.Element {
  return (
    <main className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-2xl font-bold mb-4">Parlay Labs Analytics Dashboard</h1>
      <ParlayBuilder />
      <MCMCCrossCheckPanel />
    </main>
  );
}