import React from 'react';

/**
 * ParlayBuilder
 *
 * An interactive component that will allow users to construct multi‑leg
 * parlays. This is currently a placeholder and should be extended with
 * controls for selecting events, bets and viewing combined EV.
 */
export default function ParlayBuilder(): JSX.Element {
  return (
    <div className="p-4 rounded-xl shadow bg-white">
      <h2 className="text-xl font-semibold mb-2">Parlay Builder</h2>
      <p>Coming soon — build custom parlays and see real‑time EV estimates.</p>
    </div>
  );
}